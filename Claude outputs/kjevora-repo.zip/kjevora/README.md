# KJEVORA SOFTWARE SOLUTIONS

Two front ends, one deployment, no server of its own.

```
/            the company site          (files in kj/)
/admin       the owner console         (files in admin/)
/api/*       proxied to the ERP        (see vercel.json)
```

Everything here is static. There is no build step, no `node_modules`, no
runtime. `vercel deploy` uploads files.

---

## Why there is no server in this repo

The console used to live inside the ERP repo, and moving it looked like moving
one folder. It is not. The console is two different things wearing one name:

* **`admin/`** — the dashboard the owner clicks. 34 files, every call goes to
  `/api/platform`, zero server dependencies. That is what moved here.
* **`src/platform/` in the ERP repo** — `TenantService`, `BackupService`,
  `FleetService`. **That did not move, and must not.**

`TenantService` imports the ERP's own `runMigrations` and `seedBaseline`:
creating a tenant *is* running the ERP's migration set into a fresh database.
`BackupService` re-runs those migrations on restore. `FleetService` reads ERP
tables directly.

If that code lived here it would carry a **copy** of the ERP's schema. The two
copies would agree on the day they were split and drift from that day on, and
the first client provisioned after the drift would get a database the ERP
cannot read. Nothing in this repo is worth that.

**The rule: this repo owns pixels. The ERP repo owns schema.**

## Why `/api/*` is a proxy and not a fetch to another domain

Three things break the moment the browser sees two origins:

1. **The console cookie.** `mm_platform` is `httpOnly`, `SameSite=Lax`. Cross
   site, the browser silently stops sending it and the console simply never
   logs in. The fix people reach for is `SameSite=None` plus CORS — on the
   cookie that authorises provisioning client databases. No.
2. **Landing images.** Every picture uploaded from the console is served from
   `/api/landing/asset/<slot>` — a root-relative URL. On another origin they
   all 404.
3. **There is no CORS anywhere in the ERP**, and the right amount to add is
   none.

The rewrites in `vercel.json` mean the browser only ever sees **one** origin.
Same-origin cookie, `SameSite=Lax` untouched, no CORS, no weakening of the
thing that provisions databases. The proxy is the whole trick.

**If the ERP's domain ever changes, `vercel.json` is the one file to edit.**
It is hardcoded there because Vercel rewrites cannot read environment
variables.

## Why the site's folder is still called `kj/`

Because two other places have that path baked in, and both are in the *other*
repo:

* `LandingContentService.js` answers `defaultsUrl: '/kj/defaults.js'` — the
  console imports the site's default copy from there to show "what the text
  says if you change nothing".
* `landingSections.js` builds default screenshot paths as `/kj/shots/<file>`.

Both resolve against *this* origin, so they find this repo's files and
everything works. Renaming the folder means changing the ERP and the console
in lockstep — a two-repo release to rename a directory. It is on the list, not
in this change.

## The console is still the CMS

Unchanged. `/admin` → *Landing* edits the document, `PUT /api/platform/landing`
saves it, the site merges it over `kj/defaults.js` on load. The contract is an
HTTP call, not shared code, which is exactly why the split was safe.

Two rules worth keeping in mind, both enforced in the ERP:

* `kj/defaults.js` is the **source**; the stored document is an **override**.
  An unedited deployment renders the defaults and mutates no DOM node.
* `DOCUMENT_VERSION` in `src/platform/landingDocument.js` is the reset switch.
  Bump it and every stored document — and the pictures uploaded for it — is
  discarded on read, and the page falls back to what ships here.

## Running it locally

```bash
python3 -m http.server 4173
```

Then `http://127.0.0.1:4173/kj/index.html`. The site renders its defaults with
no API at all — that is the point of `defaults.js`. The console needs the API,
so for that use `npm run dev` in the ERP repo and open its `/platform`.

## Deploying

The Vercel project is a **static** project: no framework preset, no build
command, output directory is the repo root.
