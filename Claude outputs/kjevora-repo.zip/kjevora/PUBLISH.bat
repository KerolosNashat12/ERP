@echo off
setlocal enabledelayedexpansion
title KJEVORA - publish the site and console
cd /d "%~dp0"

set "REPO=https://github.com/KerolosNashat12/kjevora.git"
set "LOG=%~dp0publish-log.txt"
set "ATTEMPTS=12"

echo Publish started %DATE% %TIME%> "%LOG%"

echo.
echo   KJEVORA SOFTWARE SOLUTIONS - publish
echo   ==========================================
echo   1. commit whatever changed in this folder
echo   2. push to GitHub (Vercel redeploys by itself)
echo.
echo   This is the KJEVORA repo. It does NOT contain the ERP,
echo   and pushing it cannot affect any client's shop.
echo.

if not exist "kj\index.html" (
  echo   [X] Wrong folder - kj\index.html is missing.
  echo.
  pause
  exit /b 1
)
if not exist "vercel.json" (
  echo   [X] Wrong folder - vercel.json is missing.
  echo.
  pause
  exit /b 1
)

where git >nul 2>nul
if errorlevel 1 (
  echo   [X] Git is not installed. Nothing was published.
  echo.
  pause
  exit /b 1
)

rem Same as the ERP's publish script: git's own TLS stack cannot reach GitHub
rem from this machine, Windows' can.
git config --global http.sslBackend schannel >> "%LOG%" 2>&1
git config --global http.version HTTP/1.1 >> "%LOG%" 2>&1

if not exist ".git" (
  echo   First publish - setting the repository up...
  git init -b main >> "%LOG%" 2>&1
  git remote add origin "%REPO%" >> "%LOG%" 2>&1
) else (
  git remote set-url origin "%REPO%" >> "%LOG%" 2>&1
)

rem ---------------------------------------------------------------------------
rem STALE GIT LOCKS - the same trap that made the ERP's publish report success
rem while committing nothing on 12 Sep 2026. index.lock guards "git add",
rem HEAD.lock guards "git commit", refs\heads\main.lock guards moving the
rem branch; clearing one is not enough. Safe because this script is the only
rem thing that touches this repository.
rem ---------------------------------------------------------------------------
set "LOCKSFOUND="
for /r ".git" %%L in (*.lock) do (
  set "LOCKSFOUND=1"
  del /f /q "%%L" >> "%LOG%" 2>&1
)
if defined LOCKSFOUND echo   Cleared a stale git lock left by an interrupted run.

echo   Committing...
git add -A >> "%LOG%" 2>&1
git -c user.email="kerolosnashatestfanous@gmail.com" -c user.name="KerolosNashat12" commit -m "Publish from PC - %DATE% %TIME%" >> "%LOG%" 2>&1
if errorlevel 1 echo   Nothing new to commit - pushing whatever is outstanding.

echo   Pushing (your connection to GitHub drops sometimes, so this retries)...
for /L %%i in (1,1,%ATTEMPTS%) do (
  echo. >> "%LOG%"
  echo --- push attempt %%i --- >> "%LOG%"
  git push origin HEAD:main >> "%LOG%" 2>&1
  if not errorlevel 1 (
    echo PUSH SUCCEEDED on attempt %%i >> "%LOG%"
    echo.
    echo   ==========================================
    echo   Pushed. Vercel builds in about 30 seconds.
    echo   ==========================================
    echo.
    pause
    exit /b 0
  )
  echo   attempt %%i failed, waiting 15s...
  timeout /t 15 /nobreak >nul
)

echo ALL PUSH ATTEMPTS FAILED >> "%LOG%"
echo.
echo   [X] GitHub could not be reached after %ATTEMPTS% tries.
echo       Run this again later, or try a phone hotspot.
echo       Details: publish-log.txt
echo.
pause
exit /b 1
