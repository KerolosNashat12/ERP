/** Request schemas. Kept in one place so the API contract is easy to review. */
import { z } from 'zod';
// The repeat vocabulary is defined once, in the module the engine and the
// browser's picker also read. Spelling the list again here is how two of them
// end up disagreeing about what 'weekly' means.
import { FREQUENCIES, DEFAULT_FREQUENCY, PERIOD_KEY_PATTERN } from '../../public/shared/recurrence.js';

const optionalString = z.string().trim().max(500).optional().nullable();

/**
 * A plain calendar day on a form, or nothing at all.
 *
 * `YYYY-MM-DD` and never a timestamp: an offer that runs "until the 30th" means
 * the whole of the 30th in the shop's own city, and the moment a time zone
 * enters the question that sentence stops being true for somebody. An empty
 * string is normalised to null, because a date field a person cleared means
 * "no end" and not "the epoch". (`isoDay` further down is the same shape for
 * payments, minus the empty-string handling a form needs.)
 */
const optionalDay = z.preprocess(
  (value) => (value === '' || value === undefined ? null : value),
  z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use a date like 2026-08-30').nullable(),
).default(null);
const money = z.coerce.number().min(0).default(0);
const id = z.coerce.number().int().positive();

export const loginSchema = z.object({
  username: z.string().trim().min(1, 'Username is required'),
  password: z.string().min(1, 'Password is required'),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(6, 'New password must be at least 6 characters'),
});

export const supplierSchema = z.object({
  code: optionalString,
  name_en: z.string().trim().min(1, 'Supplier name is required'),
  name_ar: optionalString,
  contact_person: optionalString,
  phone: optionalString,
  email: z.string().trim().email().optional().nullable().or(z.literal('')),
  address: optionalString,
  city: optionalString,
  country: optionalString,
  tax_number: optionalString,
  payment_terms_days: z.coerce.number().int().min(0).default(0),
  credit_limit: money,
  opening_balance: z.coerce.number().default(0),
  lead_time_days: z.coerce.number().int().min(0).default(7),
  notes: optionalString,
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

export const brandSchema = z.object({
  code: optionalString,
  name_en: z.string().trim().min(1, 'Brand name is required'),
  name_ar: optionalString,
  description: optionalString,
  country: optionalString,
  supplier_id: id.optional().nullable(),
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

export const categorySchema = z.object({
  code: optionalString,
  name_en: z.string().trim().min(1, 'Category name is required'),
  name_ar: optionalString,
  parent_id: id.optional().nullable(),
  description: optionalString,
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

export const warehouseSchema = z.object({
  code: optionalString,
  name_en: z.string().trim().min(1, 'Location name is required'),
  name_ar: optionalString,
  address: optionalString,
  phone: optionalString,
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

export const customerSchema = z.object({
  code: optionalString,
  name: z.string().trim().min(1, 'Customer name is required'),
  phone: optionalString,
  email: z.string().trim().email().optional().nullable().or(z.literal('')),
  address: optionalString,
  city: optionalString,
  customer_group: z.enum(['retail', 'wholesale', 'vip']).default('retail'),
  tax_number: optionalString,
  credit_limit: money,
  notes: optionalString,
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

export const attributeSchema = z.object({
  code: optionalString,
  name_en: z.string().trim().min(1, 'Attribute name is required'),
  name_ar: optionalString,
  input_type: z.enum(['select', 'color']).default('select'),
  display_order: z.coerce.number().int().default(0),
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

export const attributeValueSchema = z.object({
  code: z.string().trim().min(1, 'Value code is required').transform((v) => v.toUpperCase()),
  value_en: z.string().trim().min(1, 'Value is required'),
  value_ar: optionalString,
  color_hex: optionalString,
  display_order: z.coerce.number().int().default(0),
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

export const productSchema = z.object({
  sku_prefix: z.string().trim().min(2, 'SKU prefix is required'),
  name_en: z.string().trim().min(1, 'Product name is required'),
  name_ar: optionalString,
  description_en: optionalString,
  description_ar: optionalString,
  brand_id: id.optional().nullable(),
  category_id: id.optional().nullable(),
  supplier_id: id.optional().nullable(),
  unit: z.string().trim().default('piece'),
  tax_rate: z.coerce.number().min(0).max(100).default(0),
  base_cost: money,
  base_price: money,
  track_inventory: z.coerce.boolean().default(true),
  tags: optionalString,
  is_active: z.coerce.boolean().default(true),
  // Website visibility, and the customer-facing copy that goes with it.
  // Kept separate from the internal description so staff can write for
  // shoppers without disturbing their own notes.
  is_published: z.coerce.boolean().default(false),
  web_description_en: optionalString,
  web_description_ar: optionalString,
  /*
   * Who the piece is for, and what it costs this week.
   *
   * Both default to the values every existing product already has, so a caller
   * written before this release — an offline till replaying a queued save, the
   * bulk price tool, a script — keeps working and changes nothing by omitting
   * them. The list of words and the arithmetic behind them live in
   * shared/pricing.js; this only decides what the API will accept.
   */
  gender: z.enum(['women', 'men', 'unisex']).default('unisex'),
  discount_type: z.enum(['none', 'percent', 'amount']).default('none'),
  // A percent is a rate and a rate over 100 is always a typo; an amount is
  // money, and how much of it is too much depends on the variant's own price,
  // so that one is settled where the price is known (shared/pricing.js).
  discount_value: z.coerce.number().min(0).default(0),
  discount_starts_on: optionalDay,
  discount_ends_on: optionalDay,
  /*
   * Bundles — "more than one product, sold as one line, under a new SKU".
   *
   * `is_bundle` and `bundle_price_mode` follow the same whole-form-resend
   * rule as `track_inventory` and every other plain field on this schema
   * (the product form always sends the page it is showing), which is why
   * both default rather than being preserved when omitted. `is_deal_of_day`
   * is the one exception — it has NO default here on purpose, because it is
   * also set from a separate bulk-action screen (`bulkProductSchema` below)
   * that sends only the field it is changing; CatalogService reads its
   * absence as "leave this product's placement alone" rather than "turn it
   * off", the same rule `gender` already follows.
   */
  is_bundle: z.coerce.boolean().default(false),
  bundle_price_mode: z.enum(['fixed', 'sum']).default('fixed'),
  bundle_components: z.array(z.object({
    component_variant_id: id,
    quantity: z.coerce.number().positive('Quantity must be greater than zero').default(1),
  })).max(50).default([]),
  is_deal_of_day: z.coerce.boolean().optional(),
  attribute_ids: z.array(id).default([]),
  // May be empty: a product with no attributes gets one default variant made
  // for it, because stock, sales and labels are always keyed to a variant.
  variants: z.array(z.object({
    id: id.optional().nullable(),
    sku: optionalString,
    barcode: optionalString,
    variant_label: optionalString,
    cost_price: money,
    selling_price: money,
    wholesale_price: money.optional(),
    reorder_level: z.coerce.number().min(0).default(0),
    reorder_quantity: z.coerce.number().min(0).default(0),
    is_active: z.coerce.boolean().default(true),
    options: z.array(z.object({
      attribute_id: id,
      attribute_value_id: id,
    })).default([]),
  })).default([]),
})
  /*
   * A percentage over 100 is always a typo — an offer that pays the customer to
   * take the stock away. It is caught HERE rather than in the service because
   * the answer depends on the OTHER field, which is exactly what a schema-level
   * refinement is for; the service still clamps when it applies the rate, since
   * a value can also arrive from an older client that predates this rule.
   */
  .refine((value) => value.discount_type !== 'percent' || value.discount_value <= 100, {
    message: 'A discount cannot be more than 100%',
    path: ['discount_value'],
  })
  /*
   * And a window that closes before it opens. Refused rather than silently
   * ignored: a shop that typed the dates backwards meant to run an offer, and
   * quietly storing one that can never run is worse than saying so.
   */
  .refine((value) => !value.discount_starts_on || !value.discount_ends_on
    || value.discount_ends_on >= value.discount_starts_on, {
    message: 'The offer ends before it starts',
    path: ['discount_ends_on'],
  });

/**
 * A bulk change: which products, and what about them.
 *
 * `changes` is deliberately a partial object rather than a `field` + `value`
 * pair — the service knows which fields are bulk-editable and how to check
 * each, and a second field arriving later needs nothing here. `nullable` on the
 * three ids because clearing a brand is a real thing to want to do to a batch.
 */
/**
 * An exchange: what comes back, what goes out, and how the difference settles.
 *
 * Both lists are required and both must have something in them — an "exchange"
 * with nothing coming back is a sale, and one with nothing going out is a
 * return, and both of those have their own screens that do them properly.
 */
export const exchangeSchema = z.object({
  sale_id: id.optional().nullable(),
  invoice_no: optionalString,
  lines: z.array(z.object({
    sale_line_id: id,
    quantity: z.coerce.number().positive('Choose how many are coming back'),
    condition: z.enum(['resellable', 'damaged']).default('resellable'),
    notes: optionalString,
  })).min(1, 'Choose what the customer is bringing back').max(50),
  /*
   * The three money fields are the SAME three a sale line carries, by name and
   * by rule — because the replacement leg IS a sale and is priced by the same
   * code. The owner's case: somebody brings back a 200 bottle and takes a 500
   * one, and the shop wants to charge 400 for it, or knock something off.
   * «مش لازم السيستيم يجبرني انها تفضل 500».
   *
   * All three are optional. Sending none prices the replacement exactly as the
   * shelf does, offers included, which is what every exchange did before.
   * Sending any of them requires `sales.discount` — enforced in
   * SalesService.checkout, which this leg goes through like any other sale.
   */
  replacements: z.array(z.object({
    variant_id: id,
    quantity: z.coerce.number().positive('Choose how many are going out'),
    unit_price: z.coerce.number().min(0).optional().nullable(),
    discount_percent: z.coerce.number().min(0).max(100).default(0),
    discount_amount: money,
  })).min(1, 'Choose what the customer is taking instead').max(50),
  // How the DIFFERENCE crosses the counter, in either direction. Not how the
  // whole replacement is paid for — most of that is the credit.
  settlement_method: z.enum(['cash', 'card', 'transfer', 'wallet']).default('cash'),
  reason_code: optionalString,
  reason_note: optionalString,
  notes: optionalString,
}).refine((value) => Boolean(value.sale_id || value.invoice_no), {
  message: 'Find the original invoice first',
  path: ['invoice_no'],
});

export const bulkProductSchema = z.object({
  ids: z.array(id).min(1, 'Select at least one product').max(500),
  changes: z.object({
    gender: z.enum(['women', 'men', 'unisex']).optional(),
    brand_id: id.nullable().optional(),
    category_id: id.nullable().optional(),
    supplier_id: id.nullable().optional(),
    // Deals of the day, set on many products at once — see the doc comment
    // on `is_deal_of_day` in productSchema above.
    is_deal_of_day: z.coerce.boolean().optional(),
  }).refine((value) => Object.keys(value).length > 0, { message: 'Choose what to change' }),
});

/**
 * A page of gender decisions, confirmed at once.
 *
 * Capped at 500 so one request cannot be made to rewrite an entire catalogue by
 * accident; the screen sends a page at a time and the cap is far above it.
 */
export const genderAssignSchema = z.object({
  assignments: z.array(z.object({
    id,
    gender: z.enum(['women', 'men', 'unisex']),
  })).min(1, 'Nothing to classify').max(500),
});

export const purchaseOrderSchema = z.object({
  supplier_id: id,
  warehouse_id: id.optional().nullable(),
  order_date: z.string().trim().min(1),
  expected_date: optionalString,
  /*
   * The header discount is a RATE now (see migration 018). `discount_amount` is
   * still accepted and still means money, because an order queued by an offline
   * till before this change carries one — and because the service uses it
   * verbatim whenever no rate was sent, so nothing that already exists moves.
   */
  discount_percent: z.coerce.number().min(0).max(100).optional(),
  discount_amount: money,
  /*
   * Which of the two above the person actually typed. Absent means percent,
   * which is what every order written before this change is.
   */
  discount_type: z.enum(['percent', 'amount']).optional(),
  shipping_amount: money,
  notes: optionalString,
  status: z.enum(['draft', 'ordered']).optional(),
  lines: z.array(z.object({
    variant_id: id,
    quantity_ordered: z.coerce.number().positive(),
    unit_cost: money,
    discount_percent: z.coerce.number().min(0).max(100).default(0),
    tax_rate: z.coerce.number().min(0).max(100).default(0),
    notes: optionalString,
  })).min(1, 'Add at least one line'),
});

/**
 * Goods going back to the supplier.
 *
 * `replacement_quantity` is how many of the same came back in - it may be fewer
 * than went out, because a supplier who is short sends what he has. It is only
 * meaningful on a replacement, and the service refuses one that exceeds what
 * was sent back rather than silently capping it: a shop typing 5 when it sent 3
 * has made a mistake somebody needs to see.
 */
export const purchaseReturnSchema = z.object({
  purchase_order_id: id,
  return_date: optionalString,
  settlement: z.enum(['credit', 'refund', 'replace']).default('credit'),
  reason: optionalString,
  notes: optionalString,
  lines: z.array(z.object({
    po_line_id: id,
    quantity: z.coerce.number().positive(),
    replacement_quantity: z.coerce.number().min(0).default(0),
    /*
     * A replacement that is a DIFFERENT item. Absent means like for like, which
     * is what every replacement meant before this existed. Its cost is its own,
     * because an uneven swap has to leave the difference owing.
     */
    replacement_variant_id: id.optional().nullable(),
    replacement_unit_cost: z.coerce.number().min(0).optional().nullable(),
    reason: optionalString,
  })).min(1, 'Select at least one item to send back'),
});

export const receiveSchema = z.object({
  receipts: z.array(z.object({
    line_id: id,
    quantity: z.coerce.number().min(0),
  })).min(1),
  notes: optionalString,
});

export const saleSchema = z.object({
  customer_id: id.optional().nullable(),
  warehouse_id: id.optional().nullable(),
  sale_date: optionalString,
  promotion_code: optionalString,
  manual_discount: money,
  loyalty_redeem_points: z.coerce.number().min(0).default(0),
  payment_method: z.enum(['cash', 'card', 'transfer', 'wallet', 'credit', 'mixed']).default('cash'),
  paid_amount: z.coerce.number().min(0).optional(),
  payments: z.array(z.object({
    amount: z.coerce.number().min(0),
    method: z.enum(['cash', 'card', 'transfer', 'wallet', 'credit']).default('cash'),
    reference: optionalString,
  })).optional(),
  notes: optionalString,
  lines: z.array(z.object({
    key: z.union([z.string(), z.number()]).optional(),
    variant_id: id,
    quantity: z.coerce.number().positive(),
    unit_price: z.coerce.number().min(0).optional().nullable(),
    discount_percent: z.coerce.number().min(0).max(100).default(0),
    discount_amount: money,
  })).min(1, 'The sale has no items'),
});

export const returnSchema = z.object({
  return_type: z.enum(['with_receipt', 'no_receipt']).default('with_receipt'),
  sale_id: id.optional().nullable(),
  invoice_no: optionalString,
  customer_id: id.optional().nullable(),
  reason_code: z.enum([
    'defective', 'wrong_item', 'wrong_size', 'not_as_described',
    'changed_mind', 'damaged_in_transit', 'duplicate', 'other',
  ]).default('other'),
  reason_note: optionalString,
  refund_method: z.enum(['cash', 'card', 'transfer', 'wallet', 'store_credit', 'account']).default('cash'),
  restocking_fee: money,
  lines: z.array(z.object({
    sale_line_id: id.optional().nullable(),
    variant_id: id.optional().nullable(),
    quantity: z.coerce.number().min(0),
    condition: z.enum(['resellable', 'damaged']).default('resellable'),
    notes: optionalString,
  })).min(1, 'Select at least one item to return'),
}).refine(
  (data) => data.return_type === 'no_receipt' || Boolean(data.sale_id || data.invoice_no),
  { message: 'An invoice is required for a receipted return', path: ['invoice_no'] },
);

export const promotionSchema = z.object({
  code: z.string().trim().min(2, 'Code is required'),
  name_en: z.string().trim().min(1, 'Name is required'),
  name_ar: optionalString,
  kind: z.enum(['discount', 'voucher']).default('discount'),
  discount_type: z.enum(['percentage', 'fixed']).default('percentage'),
  value: z.coerce.number().min(0),
  scope: z.enum(['order', 'product', 'category', 'brand']).default('order'),
  min_order_amount: money,
  max_discount_amount: money,
  voucher_balance: money.optional(),
  starts_at: optionalString,
  ends_at: optionalString,
  usage_limit: z.coerce.number().int().min(0).default(0),
  per_customer_limit: z.coerce.number().int().min(0).default(0),
  customer_group: z.enum(['retail', 'wholesale', 'vip']).optional().nullable().or(z.literal('')),
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
  targets: z.array(z.object({
    target_type: z.enum(['product', 'category', 'brand', 'variant']),
    target_id: id,
  })).optional(),
});

export const adjustmentSchema = z.object({
  warehouse_id: id.optional().nullable(),
  reason: z.enum(['stock_take', 'damage', 'loss', 'theft', 'correction', 'expiry', 'other']).default('stock_take'),
  notes: optionalString,
  lines: z.array(z.object({
    variant_id: id,
    system_qty: z.coerce.number(),
    counted_qty: z.coerce.number().min(0),
    unit_cost: money,
    notes: optionalString,
  })).min(1, 'Add at least one line'),
});

/**
 * الهدر. The reasons are the losing subset of an adjustment's reasons —
 * `stock_take` and `correction` are bookkeeping, not loss, and are refused here
 * so that the wastage figure cannot be polluted from this door.
 */
export const wastageSchema = z.object({
  variantId: id,
  warehouseId: id.optional().nullable(),
  quantity: z.coerce.number().positive('How many were lost?'),
  reason: z.enum(['damage', 'loss', 'theft', 'expiry']),
  notes: optionalString,
});

/**
 * Deleting something into the recycle bin. The entity type is checked against
 * the policy registry rather than against a list here — one place decides what
 * may be deleted (services/trash/policies.js) and this only checks the shape.
 */
export const trashDeleteSchema = z.object({
  entityType: z.string().trim().min(1),
  entityId: id,
  reason: optionalString,
});

export const quickAdjustSchema = z.object({
  variantId: id,
  warehouseId: id.optional().nullable(),
  newQuantity: z.coerce.number().min(0),
  reason: z.enum(['stock_take', 'damage', 'loss', 'theft', 'correction', 'expiry', 'other']).default('correction'),
  notes: optionalString,
});

export const userSchema = z.object({
  username: z.string().trim().min(3, 'Username must be at least 3 characters'),
  full_name: z.string().trim().min(1, 'Full name is required'),
  email: z.string().trim().email().optional().nullable().or(z.literal('')),
  phone: optionalString,
  password: z.string().min(6, 'Password must be at least 6 characters'),
  role_id: id,
  default_warehouse_id: id.optional().nullable(),
  language: z.enum(['en', 'ar']).default('en'),
  is_active: z.coerce.boolean().default(true),
  must_change_password: z.coerce.boolean().default(false),
});

export const userUpdateSchema = userSchema
  .partial({ password: true, username: true })
  .extend({ unlock: z.coerce.boolean().optional() });

/**
 * A photograph attached to something — a supplier payment today, a cost and a
 * salary slip next. Only the shape is checked here: what the bytes actually
 * ARE is decided by `shared/imageCodec.js`, which sniffs them, because a
 * declared type is a claim and a filename is a suggestion. See the contract at
 * the top of services/AttachmentService.js.
 */
export const attachedPhotoSchema = z.object({
  dataUrl: z.string().min(1, 'A photograph is required'),
  thumbDataUrl: z.string().min(1).optional().nullable(),
  caption: z.string().trim().max(300).optional().nullable(),
});

/** YYYY-MM-DD, the way every other date in this system is stored. */
const isoDay = z.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use a YYYY-MM-DD date');

export const paymentSchema = z.object({
  amount: z.coerce.number().positive('Amount must be greater than zero'),
  method: z.string().trim().default('cash'),
  reference: optionalString,
  note: optionalString,
  paidOn: isoDay.optional().nullable(),
  photo: attachedPhotoSchema.optional().nullable(),
});

export const paymentReversalSchema = z.object({
  reason: z.string().trim().min(1, 'Say why this payment is being reversed').max(500),
});

/**
 * A cost — what the shop spent, on what, at which branch.
 *
 * `amount` is coerced and validated here and rounded again in the service:
 * nothing the browser calculated is trusted as a total, and this schema is only
 * the first of the two gates.
 */
export const costSchema = z.object({
  category_id: id,
  warehouse_id: id.optional().nullable(),
  spent_on: isoDay.optional().nullable(),
  amount: z.coerce.number().positive('A cost must be greater than zero'),
  description: optionalString,
  reference: optionalString,
  payment_method: z.string().trim().default('cash'),
  photo: attachedPhotoSchema.optional().nullable(),
});

export const costCategorySchema = z.object({
  code: optionalString,
  name_en: z.string().trim().min(1, 'A name is required'),
  name_ar: optionalString,
  display_order: z.coerce.number().int().min(0).default(100),
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

/** The template, not the cost: rent, every month, on the day it falls due. */
export const recurringCostSchema = z.object({
  category_id: id,
  warehouse_id: id.optional().nullable(),
  description: optionalString,
  amount: z.coerce.number().positive('A repeating cost must be greater than zero'),
  payment_method: z.string().trim().default('cash'),
  /*
   * HOW OFTEN. The list is `FREQUENCIES` in src/shared/costs.js rather than
   * spelled again here — the same module the browser's picker and the engine
   * read, so the three cannot disagree about what is a valid repeat. There is
   * no CHECK constraint in the database on purpose (see migration 030), which
   * makes this schema the place an unknown value is stopped.
   */
  frequency: z.enum(FREQUENCIES).default(DEFAULT_FREQUENCY),
  // 1–31, clamped to the length of each month when the date is computed — a
  // "31st" template lands on the 28th of February rather than being skipped.
  // Read by monthly and yearly; ignored by the other two.
  day_of_month: z.coerce.number().int().min(1).max(31).default(1),
  // Weekly only, 0 Sunday … 6 Saturday. Optional because the service derives
  // it from the start date when it is not sent.
  day_of_week: z.coerce.number().int().min(0).max(6).optional().nullable(),
  // Yearly only, 1–12. Derived from the start date the same way.
  month_of_year: z.coerce.number().int().min(1).max(12).optional().nullable(),
  starts_on: isoDay,
  ends_on: isoDay.optional().nullable(),
});

/** Confirming one waiting month. The amount may differ from the template's. */
export const recurringPostSchema = z.object({
  /*
   * The key's SHAPE follows the template's frequency — 'YYYY-MM-DD' for a
   * daily or weekly repeat, 'YYYY-MM' for a monthly one, 'YYYY' for a yearly
   * one. This only rejects something that is no shape at all; whether the key
   * is genuinely due on THAT template is decided by the service against the
   * occurrences it computes, which is the check that actually matters.
   */
  period_key: z.string().trim().regex(PERIOD_KEY_PATTERN, 'Use a YYYY, YYYY-MM or YYYY-MM-DD key'),
  amount: z.coerce.number().positive().optional().nullable(),
  spent_on: isoDay.optional().nullable(),
});

/**
 * Somebody the shop pays. Nothing here beyond what paying them needs: a name,
 * a job, a phone, an amount and how often. No address, no identity document,
 * no date of birth — a shop's payroll is not a personnel file.
 */
export const employeeSchema = z.object({
  code: optionalString,
  name: z.string().trim().min(1, 'A name is required'),
  job_title: optionalString,
  phone: optionalString,
  salary_amount: z.coerce.number().min(0).default(0),
  salary_period: z.enum(['day', 'week', 'month']).default('month'),
  warehouse_id: id.optional().nullable(),
  hired_on: isoDay.optional().nullable(),
  notes: optionalString,
  is_active: z.coerce.boolean().default(true).transform((v) => (v ? 1 : 0)),
});

/**
 * فواتيرك — one invoice the shop already has on paper.
 *
 * `total_amount` is `.nullable()` on purpose and it is the interesting part of
 * this schema: he photographs a bill today and reads the amount off it next
 * week. It is coerced here and rounded again in the service — nothing the
 * browser calculated is trusted as a total, and this is only the first of the
 * two gates. `paid_amount` and `status` are absent because a caller may not
 * send either: both are derived from the payment rows by the database.
 *
 * `photos` is a LIST, because a paper invoice runs to several pages —
 * *"وتكون اكتر من صوره"*. Capped at 20: a longer invoice than that is a folder,
 * and 20 photographs is already 5 MB of request.
 */
export const legacyInvoiceSchema = z.object({
  title: z.string().trim().min(1, 'Give this invoice a name so you can find it again').max(200),
  supplier_id: id,
  invoice_no: optionalString,
  invoice_date: isoDay.optional().nullable(),
  total_amount: z.coerce.number().positive('An invoice total must be greater than zero')
    .optional().nullable(),
  notes: optionalString,
  photos: z.array(attachedPhotoSchema).max(20, 'That is more photographs than one invoice needs')
    .optional().default([]),
});

/** A payment against one of those records. The receipt is optional — see the service. */
export const legacyInvoicePaymentSchema = paymentSchema;

/** What was actually handed over, when, for which period. */
export const salaryPaymentSchema = z.object({
  amount: z.coerce.number().positive('Amount must be greater than zero'),
  paid_on: isoDay.optional().nullable(),
  period_start: isoDay.optional().nullable(),
  period_end: isoDay.optional().nullable(),
  payment_method: z.string().trim().default('cash'),
  reference: optionalString,
  note: optionalString,
  photo: attachedPhotoSchema.optional().nullable(),
});

export const labelBatchSchema = z.object({
  items: z.array(z.object({
    variant_id: id,
    copies: z.coerce.number().int().min(1).max(200).default(1),
  })).min(1, 'Select at least one item'),
  labelSize: z.string().trim().default('40x30'),
  qrSize: z.coerce.number().int().min(80).max(400).default(180),
  // Overrides `labels.symbology` for this one batch; omitted uses the setting.
  symbology: z.enum(['code128', 'ean13', 'qr']).optional(),
});

export const voucherBatchSchema = z.object({
  prefix: z.string().trim().min(1).max(8).default('MMV'),
  count: z.coerce.number().int().min(1).max(500).default(10),
  value: z.coerce.number().positive(),
  expiresAt: optionalString,
});

/** Username only — a locked-out user has nothing else to offer. */
export const forgotPasswordSchema = z.object({
  username: z.string().min(1, 'Username is required'),
  note: z.string().max(300).optional().nullable(),
});

/**
 * A product photo arrives as a base64 data URL — the browser has already
 * resized and re-encoded it, so there is no multipart upload anywhere in this
 * system. Content type and size are checked against the decoded bytes in
 * ImageService; this only guards the shape.
 */
export const productImageSchema = z.object({
  dataUrl: z.string().min(1, 'A photo is required'),
  variantId: id.optional().nullable(),
  altEn: optionalString,
  altAr: optionalString,
});

export const productImageUpdateSchema = z.object({
  variantId: id.optional().nullable(),
  altEn: optionalString,
  altAr: optionalString,
});

export const imageOrderSchema = z.object({
  ids: z.array(id).default([]),
});

/** The website banner image — same shape as a product photo, its own endpoint. */
export const websiteBannerSchema = z.object({
  dataUrl: z.string().min(1, 'A photo is required'),
});

/**
 * The shop's logo. Same shape, its own message: an owner told "a photo is
 * required" while looking at a Logo card is being answered by somebody else's
 * screen. The bytes themselves — type, size and the PNG that must stay a PNG —
 * are checked in WebAssetService against what was actually decoded.
 */
export const websiteLogoSchema = z.object({
  dataUrl: z.string().min(1, 'A logo image is required'),
});

/**
 * A basket from the public internet.
 *
 * The only thing believed here is the SHAPE. Prices are absent from the schema
 * on purpose — the browser sends a variant and a quantity, and WebOrderService
 * looks the price up itself, so a client cannot name its own. Every string is
 * trimmed and length-capped at the boundary rather than in the service, because
 * this is the one schema whose input nobody has signed in to send.
 */
const publicText = (max) => z.string().trim().max(max);
const optionalPublicText = (max) => publicText(max).optional().nullable().or(z.literal(''));

export const webOrderSchema = z.object({
  lines: z.array(z.object({
    variant_id: id,
    quantity: z.coerce.number().int().min(1).max(99),
  })).min(1, 'Your basket is empty').max(50, 'An order can hold at most 50 items'),
  customer: z.object({
    name: publicText(120).min(1, 'Your name is required'),
    // Cash on delivery and a courier who has to ring the bell: the phone number
    // is the order's identity, and it is what `track()` checks against.
    phone: publicText(20).min(6, 'A valid phone number is required'),
    email: publicText(160).email().optional().nullable().or(z.literal('')),
  }),
  address: z.object({
    line: publicText(300).min(1, 'A delivery address is required'),
    area: optionalPublicText(120),
    city: publicText(120).min(1, 'A city is required'),
    notes: optionalPublicText(300),
  }),
  note: optionalPublicText(500),
  language: z.enum(['en', 'ar']).default('ar'),
});
